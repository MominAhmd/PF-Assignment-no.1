#include <stdio.h>

#define SIZE 20
#define LEN 4

int main() {
    int grid[SIZE][SIZE] = {
        {8, 2, 22, 97, 38, 15, 0, 40, 0, 75, 4, 5, 7, 78, 52, 12, 50, 77, 91, 8},
        {49, 49, 99, 40, 17, 81, 18, 57, 60, 87, 17, 40, 98, 43, 69, 48, 4, 56, 62, 0},
        {81, 49, 31, 73, 55, 79, 14, 29, 93, 71, 40, 67, 53, 88, 30, 3, 49, 13, 36, 65},
        // ... rest of the grid ...
    };

    int i, j, k;
    long product, max_product = 0;

    for (i = 0; i < SIZE; i++) {
        for (j = 0; j < SIZE; j++) {
            if (j + LEN <= SIZE) { // horizontal
                product = 1;
                for (k = 0; k < LEN; k++) {
                    product *= grid[i][j + k];
                }
                if (product > max_product) {
                    max_product = product;
                }
            }

            if (i + LEN <= SIZE) { // vertical
                product = 1;
                for (k = 0; k < LEN; k++) {
                    product *= grid[i + k][j];
                }
                if (product > max_product) {
                    max_product = product;
                }
            }

            if (i + LEN <= SIZE && j + LEN <= SIZE) { // diagonal down
                product = 1;
                for (k = 0; k < LEN; k++) {
                    product *= grid[i + k][j + k];
                }
                if (product > max_product) {
                    max_product = product;
                }
            }

            if (i - LEN >= -1 && j + LEN <= SIZE) { // diagonal up
                product = 1;
                for (k = 0; k < LEN; k++) {
                    product *= grid[i - k][j + k];
                }
                if (product > max_product) {
                    max_product = product;
                }
            }
        }
    }

    printf("The largest product of four adjacent numbers in the same direction is %ld\n", max_product);

    return 0;
}

