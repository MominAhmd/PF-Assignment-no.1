#include <stdio.h>

void CollatzSequence(int *a){
		(*a)++;
}

int LongestCollatz(int *a ){
int count=1;

while(*a!=1){
	
	if(*a%2==0){
		*a= *a/2;
		CollatzSequence(&count);	
	}
	else{
		*a= (*a*3) + 1;
	CollatzSequence(&count);	
	} 
}	
	return count;

}


int main(){
	int n;
	
	while(1){
	printf("Kindly Enter a number: ");
	scanf("%d", &n);
	
	if (n>0){break;}
}

	printf("Your Number is: %d", n);
	
	printf(" and with a length of %d", LongestCollatz(&n));


return 0;
}

